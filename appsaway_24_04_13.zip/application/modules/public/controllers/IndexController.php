<?php
class IndexController extends MF_Controller{
	
	public function _init(){
	}
	public function indexAction(){
	}
}